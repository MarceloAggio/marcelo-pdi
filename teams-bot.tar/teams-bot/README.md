# 🤖 Teams Bot — Node.js + TypeScript

Bot para Microsoft Teams escalável e funcional. Responde **qualquer mensagem no privado** e, nos **grupos/canais**, somente reage ao prefixo `/bot`.

---

## 📁 Estrutura do Projeto

```
teams-bot/
├── src/
│   ├── index.ts                  # Entry point
│   ├── bot/
│   │   └── TeamsBot.ts           # Classe principal do bot
│   ├── handlers/
│   │   └── messageHandlers.ts    # Lógica de privado e grupo
│   ├── middleware/
│   │   └── index.ts              # Log + tratamento de erros
│   ├── server/
│   │   └── index.ts              # Express + BotFrameworkAdapter
│   ├── config/
│   │   └── index.ts              # Carrega variáveis de ambiente
│   ├── utils/
│   │   └── logger.ts             # Winston logger
│   └── types/
│       └── index.ts              # Tipos TypeScript
├── manifest/
│   └── manifest.json             # Manifesto do Teams App
├── Dockerfile
├── docker-compose.yml
├── .env.example
├── tsconfig.json
└── package.json
```

---

## ⚙️ Configuração

### 1. Pré-requisitos

- Node.js 20+
- Conta Microsoft 365 com permissão para registrar bots
- [Bot Framework Emulator](https://github.com/microsoft/BotFramework-Emulator) (opcional, para testes locais)
- [ngrok](https://ngrok.com) (para expor o servidor local ao Teams)

### 2. Registrar o Bot no Azure

1. Acesse o [Azure Portal](https://portal.azure.com)
2. Crie um recurso **Azure Bot**
3. Copie o **App ID** e gere um **Client Secret** (senha)
4. No campo **Messaging endpoint**, coloque: `https://SEU_DOMINIO/api/messages`

### 3. Instalar dependências

```bash
npm install
```

### 4. Configurar variáveis de ambiente

```bash
cp .env.example .env
# Edite o .env com seu App ID e senha
```

```env
MICROSOFT_APP_ID=seu-app-id
MICROSOFT_APP_PASSWORD=sua-senha
PORT=3978
```

### 5. Rodar em desenvolvimento

```bash
npm run dev
```

### 6. Expor via ngrok (para testes com Teams real)

```bash
ngrok http 3978
# Copie a URL HTTPS e configure no Azure Bot como Messaging Endpoint
```

---

## 🚀 Deploy

### Docker

```bash
docker-compose up -d
```

### Build manual

```bash
npm run build
npm start
```

---

## 💬 Comportamento do Bot

### Privado (Personal Chat)
Responde **qualquer mensagem** sem precisar de prefixo.

| Mensagem     | Resposta                        |
|--------------|---------------------------------|
| `oi`         | Eco + instruções de uso         |
| `/help`      | Lista de comandos               |
| `/ping`      | Pong! Confirmação de conexão    |
| `/info`      | Status do bot (uptime, memória) |

### Grupo / Canal
Responde **somente** quando a mensagem começa com `/bot`.

| Comando         | Resposta                        |
|-----------------|---------------------------------|
| `/bot help`     | Lista de comandos do grupo      |
| `/bot ping`     | Pong! Confirmação de conexão    |
| `/bot info`     | Status do bot com horário       |
| `/bot <outro>`  | Aviso de comando desconhecido   |

---

## 🏗️ Arquitetura

```
HTTP Request (Teams)
       │
       ▼
 Express Server (/api/messages)
       │
       ▼
 BotFrameworkAdapter
       │
  ┌────┴────┐
  │Middleware│  ← LogMiddleware → ErrorMiddleware
  └────┬────┘
       │
       ▼
   TeamsBot (ActivityHandler)
       │
  ┌────┴──────────────┐
  │                   │
  ▼                   ▼
isGroup?          isPrivate?
  │                   │
  ▼                   ▼
routeGroup       handlePrivate
  │
  ▼
starts with /bot?
  ├─ yes → handleGroupMessage(command)
  └─ no  → ignore silently
```

---

## 🔧 Adicionando Novos Comandos

### No grupo (`src/handlers/messageHandlers.ts`):

```typescript
const meuComandoHandler: CommandHandler = {
  command: 'meucomando',
  description: 'Descrição do comando',
  handler: async ({ ctx, senderName }) => {
    await ctx.sendActivity(`Olá ${senderName}!`);
  },
};

// Adicione no objeto handlers dentro de handleGroupMessage:
const handlers: Record<string, CommandHandler> = {
  // ... existentes
  meucomando: meuComandoHandler,
};
```

### No privado:

```typescript
if (normalized === '/meucomando') {
  await ctx.sendActivity('Resposta do meu comando!');
  return;
}
```

---

## 📦 Escalabilidade

Para produção em escala, substitua o `MemoryStorage` por:

- **Azure Cosmos DB**: `CosmosDbPartitionedStorage` do pacote `botbuilder-azure`
- **Redis**: `RedisStorage` do pacote `botbuilder-redis`

```typescript
// Exemplo com CosmosDB
import { CosmosDbPartitionedStorage } from 'botbuilder-azure';
const storage = new CosmosDbPartitionedStorage({ ... });
```

---

## 🛡️ Variáveis de Ambiente

| Variável                  | Obrigatória | Descrição                   |
|---------------------------|-------------|-----------------------------|
| `MICROSOFT_APP_ID`        | ✅           | App ID do Azure Bot         |
| `MICROSOFT_APP_PASSWORD`  | ✅           | Client Secret do Azure Bot  |
| `PORT`                    | ❌           | Porta HTTP (padrão: 3978)   |
| `NODE_ENV`                | ❌           | `development` / `production`|
| `LOG_LEVEL`               | ❌           | `debug` / `info` / `warn`  |

---

## 📦 Publicar no Teams

1. Coloque o `MICROSOFT_APP_ID` no `manifest/manifest.json`
2. Adicione ícones `color.png` (192x192) e `outline.png` (32x32) na pasta `manifest/`
3. Compacte a pasta `manifest/` em um `.zip`
4. No Teams → **Apps** → **Fazer upload de um app personalizado** → selecione o `.zip`
