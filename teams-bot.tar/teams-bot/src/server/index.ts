import express, { Application, Request, Response } from 'express';
import {
  BotFrameworkAdapter,
  ConversationState,
  MemoryStorage,
  UserState,
} from 'botbuilder';
import { TeamsBot } from '../bot/TeamsBot';
import { LogMiddleware, ErrorMiddleware } from '../middleware';
import { botConfig } from '../config';
import { logger } from '../utils/logger';

export function createServer(): Application {
  const app = express();
  app.use(express.json());

  // ─── Adapter ───────────────────────────────────────────────────────────────

  const adapter = new BotFrameworkAdapter({
    appId: botConfig.appId,
    appPassword: botConfig.appPassword,
  });

  // Middleware de pipeline
  adapter.use(new LogMiddleware());
  adapter.use(new ErrorMiddleware());

  // Tratamento global de erros do adapter
  adapter.onTurnError = async (ctx, error) => {
    logger.error('Erro não tratado no turno do bot', {
      error: error.message,
      stack: error.stack,
    });
    await ctx.sendActivity('⚠️ Algo deu errado. Tente novamente em instantes.');
  };

  // ─── Estado (em memória, substituir por CosmosDB/Redis em produção) ───────

  const memoryStorage = new MemoryStorage();
  const _conversationState = new ConversationState(memoryStorage);
  const _userState = new UserState(memoryStorage);

  // ─── Bot ───────────────────────────────────────────────────────────────────

  const bot = new TeamsBot();

  // ─── Rotas ─────────────────────────────────────────────────────────────────

  // Endpoint principal do bot (Teams envia mensagens aqui)
  app.post('/api/messages', async (req: Request, res: Response) => {
    await adapter.processActivity(req, res, async (ctx) => {
      await bot.run(ctx);
    });
  });

  // Health check
  app.get('/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      uptime: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
      botId: botConfig.appId,
    });
  });

  // Rota raiz
  app.get('/', (_req: Request, res: Response) => {
    res.json({
      name: 'Teams Bot',
      version: '1.0.0',
      endpoints: {
        messages: 'POST /api/messages',
        health: 'GET /health',
      },
    });
  });

  logger.info('Servidor Express configurado');
  return app;
}
