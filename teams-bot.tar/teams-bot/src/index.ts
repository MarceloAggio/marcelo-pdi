import { createServer } from './server';
import { botConfig } from './config';
import { logger } from './utils/logger';

async function bootstrap(): Promise<void> {
  try {
    const app = createServer();

    app.listen(botConfig.port, () => {
      logger.info(`🤖 Teams Bot iniciado com sucesso!`);
      logger.info(`📡 Endpoint: http://localhost:${botConfig.port}/api/messages`);
      logger.info(`❤️  Health:   http://localhost:${botConfig.port}/health`);
      logger.info(`🆔 App ID:   ${botConfig.appId}`);
    });
  } catch (err) {
    logger.error('Falha ao iniciar o bot', {
      error: err instanceof Error ? err.message : String(err),
    });
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM recebido — encerrando graciosamente...');
  process.exit(0);
});

process.on('SIGINT', () => {
  logger.info('SIGINT recebido — encerrando graciosamente...');
  process.exit(0);
});

bootstrap();
