import { TurnContext, Middleware } from 'botbuilder';
import { logger } from '../utils/logger';

// ─── Log Middleware ───────────────────────────────────────────────────────────

export class LogMiddleware implements Middleware {
  async onTurn(ctx: TurnContext, next: () => Promise<void>): Promise<void> {
    const { type, from, conversation } = ctx.activity;

    logger.debug('Atividade recebida', {
      type,
      sender: from?.name,
      conversationType: conversation?.conversationType,
    });

    const start = Date.now();
    await next();
    logger.debug(`Atividade processada em ${Date.now() - start}ms`);
  }
}

// ─── Error Middleware ─────────────────────────────────────────────────────────

export class ErrorMiddleware implements Middleware {
  async onTurn(ctx: TurnContext, next: () => Promise<void>): Promise<void> {
    try {
      await next();
    } catch (err) {
      logger.error('Erro ao processar atividade', {
        error: err instanceof Error ? err.message : String(err),
        stack: err instanceof Error ? err.stack : undefined,
      });

      try {
        await ctx.sendActivity(
          '⚠️ Ocorreu um erro ao processar sua mensagem. Tente novamente mais tarde.'
        );
      } catch {
        logger.error('Falha ao enviar mensagem de erro ao usuário');
      }
    }
  }
}
