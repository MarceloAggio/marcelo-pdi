import { TurnContext } from 'botbuilder';

export interface BotConfig {
  appId: string;
  appPassword: string;
  port: number;
}

export interface MessageContext {
  ctx: TurnContext;
  text: string;
  isGroup: boolean;
  isPrivate: boolean;
  senderId: string;
  senderName: string;
  conversationId: string;
}

export type HandlerFn = (context: MessageContext) => Promise<void>;

export interface CommandHandler {
  command: string;
  description: string;
  handler: HandlerFn;
}
