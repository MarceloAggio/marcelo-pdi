import dotenv from 'dotenv';
import { BotConfig } from '../types';

dotenv.config();

function requireEnv(key: string): string {
  const value = process.env[key];
  if (!value) throw new Error(`Variável de ambiente obrigatória não definida: ${key}`);
  return value;
}

export const botConfig: BotConfig = {
  appId: requireEnv('MICROSOFT_APP_ID'),
  appPassword: requireEnv('MICROSOFT_APP_PASSWORD'),
  port: parseInt(process.env['PORT'] ?? '3978', 10),
};

export const env = {
  isDev: process.env['NODE_ENV'] !== 'production',
  logLevel: process.env['LOG_LEVEL'] ?? 'info',
};
