import {
  ActivityHandler,
  TurnContext,
  ChannelAccount,
  TeamsActivityHandler,
} from 'botbuilder';
import { MessageContext } from '../types';
import { handleGroupMessage, handlePrivateMessage } from '../handlers/messageHandlers';
import { logger } from '../utils/logger';

// ─── Constantes ───────────────────────────────────────────────────────────────

const BOT_TRIGGER = '/bot';
const PRIVATE_CONVERSATION_TYPES = ['personal', 'direct', 'directMessage'];

// ─── TeamsBot ─────────────────────────────────────────────────────────────────

export class TeamsBot extends TeamsActivityHandler {
  constructor() {
    super();
    this.setupHandlers();
  }

  private setupHandlers(): void {
    // Mensagens de texto
    this.onMessage(async (ctx, next) => {
      await this.processMessage(ctx);
      await next();
    });

    // Bot adicionado a um grupo/conversa
    this.onMembersAdded(async (ctx, next) => {
      await this.handleMembersAdded(ctx);
      await next();
    });

    // Bot removido de um grupo
    this.onMembersRemoved(async (ctx, next) => {
      const removed = ctx.activity.membersRemoved ?? [];
      const botId = ctx.activity.recipient.id;
      const wasBot = removed.some((m) => m.id === botId);
      if (wasBot) {
        logger.info('Bot removido da conversa', {
          conversationId: ctx.activity.conversation.id,
        });
      }
      await next();
    });
  }

  // ─── Processa mensagens recebidas ─────────────────────────────────────────

  private async processMessage(ctx: TurnContext): Promise<void> {
    const activity = ctx.activity;
    const rawText = this.stripMentions(ctx);
    const conversationType = activity.conversation?.conversationType ?? 'personal';
    const isGroup = !PRIVATE_CONVERSATION_TYPES.includes(conversationType);

    const messageCtx: MessageContext = {
      ctx,
      text: rawText,
      isGroup,
      isPrivate: !isGroup,
      senderId: activity.from?.id ?? '',
      senderName: activity.from?.name ?? 'Usuário',
      conversationId: activity.conversation?.id ?? '',
    };

    if (isGroup) {
      await this.routeGroupMessage(messageCtx);
    } else {
      await handlePrivateMessage(messageCtx);
    }
  }

  // ─── Roteamento de grupo ──────────────────────────────────────────────────

  private async routeGroupMessage(context: MessageContext): Promise<void> {
    const { text, ctx } = context;
    const normalized = text.trim().toLowerCase();

    // Somente processa se a mensagem começar com /bot
    if (!normalized.startsWith(BOT_TRIGGER)) {
      logger.debug('[GRUPO] Mensagem ignorada (sem /bot)', { text });
      return;
    }

    // Verifica se há conteúdo após /bot
    const afterTrigger = text.trim().slice(BOT_TRIGGER.length).trim();
    if (!afterTrigger) {
      await ctx.sendActivity(
        `👋 Olá! Use \`/bot help\` para ver os comandos disponíveis.`
      );
      return;
    }

    await handleGroupMessage(context);
  }

  // ─── Boas-vindas ao ser adicionado ────────────────────────────────────────

  private async handleMembersAdded(ctx: TurnContext): Promise<void> {
    const added: ChannelAccount[] = ctx.activity.membersAdded ?? [];
    const botId = ctx.activity.recipient.id;

    for (const member of added) {
      // Ignora quando o próprio bot é adicionado ao grupo (evitar duplicata)
      if (member.id === botId) {
        const isGroup = !PRIVATE_CONVERSATION_TYPES.includes(
          ctx.activity.conversation?.conversationType ?? 'personal'
        );

        if (isGroup) {
          logger.info('Bot adicionado a grupo', {
            conversationId: ctx.activity.conversation.id,
          });
          await ctx.sendActivity(
            '👋 **Olá, equipe!** Estou aqui e pronto para ajudar.\n\n' +
              '📌 **Como me usar no grupo:**\n' +
              '• Use `/bot help` para ver os comandos disponíveis\n' +
              '• Todas as mensagens de grupo precisam do prefixo `/bot`\n\n' +
              '💬 **No privado:** pode me enviar mensagens diretamente, sem prefixo!'
          );
        } else {
          await ctx.sendActivity(
            '👋 **Olá!** Sou seu assistente no Teams.\n\n' +
              'Pode me enviar qualquer mensagem aqui no privado.\n' +
              'Use `/help` para ver os comandos disponíveis.'
          );
        }
        break;
      }
    }
  }

  // ─── Remove menções ao bot do texto ──────────────────────────────────────

  private stripMentions(ctx: TurnContext): string {
    let text = ctx.activity.text ?? '';

    const entities = ctx.activity.entities ?? [];
    for (const entity of entities) {
      if (entity.type === 'mention') {
        const mention = entity as { mentioned?: { id?: string }; text?: string };
        if (mention.text) {
          text = text.replace(mention.text, '').trim();
        }
      }
    }

    // Remove tags HTML residuais do Teams
    text = text.replace(/<at>[^<]*<\/at>/gi, '').trim();
    text = text.replace(/<[^>]+>/g, '').trim();

    return text;
  }
}
