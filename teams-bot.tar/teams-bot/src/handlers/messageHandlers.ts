import { CommandHandler, MessageContext } from '../types';
import { logger } from '../utils/logger';

// ─── Handlers de Grupo (/bot <comando>) ─────────────────────────────────────

const groupHelpHandler: CommandHandler = {
  command: 'help',
  description: 'Lista os comandos disponíveis no grupo',
  handler: async ({ ctx }) => {
    await ctx.sendActivity(
      '📋 **Comandos disponíveis no grupo:**\n\n' +
        '• `/bot help` — Exibe esta ajuda\n' +
        '• `/bot ping` — Verifica se o bot está online\n' +
        '• `/bot info` — Informações sobre o bot\n\n' +
        '_No privado, pode enviar qualquer mensagem sem prefixo._'
    );
  },
};

const groupPingHandler: CommandHandler = {
  command: 'ping',
  description: 'Verifica se o bot está online',
  handler: async ({ ctx }) => {
    await ctx.sendActivity('🏓 **Pong!** Bot operacional.');
  },
};

const groupInfoHandler: CommandHandler = {
  command: 'info',
  description: 'Informações sobre o bot',
  handler: async ({ ctx, senderName }) => {
    const now = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
    await ctx.sendActivity(
      `ℹ️ **Teams Bot**\n\n` +
        `👤 Solicitado por: **${senderName}**\n` +
        `🕐 Horário: ${now}\n` +
        `⚙️ Runtime: Node.js ${process.version}\n` +
        `🌐 Ambiente: ${process.env['NODE_ENV'] ?? 'development'}`
    );
  },
};

// ─── Handler padrão de Grupo ─────────────────────────────────────────────────

export async function handleGroupMessage(context: MessageContext): Promise<void> {
  const { ctx, text } = context;

  // Extrai o comando após /bot
  const parts = text.trim().split(/\s+/);
  const subCommand = parts[1]?.toLowerCase() ?? 'help';

  const handlers: Record<string, CommandHandler> = {
    help: groupHelpHandler,
    ping: groupPingHandler,
    info: groupInfoHandler,
  };

  const found = handlers[subCommand];

  if (found) {
    logger.info(`[GRUPO] Comando: /bot ${subCommand}`, { sender: context.senderName });
    await found.handler(context);
  } else {
    logger.warn(`[GRUPO] Comando desconhecido: /bot ${subCommand}`);
    await ctx.sendActivity(
      `❓ Comando **${subCommand}** não reconhecido.\n` +
        `Use \`/bot help\` para ver os comandos disponíveis.`
    );
  }
}

// ─── Handler de Privado ───────────────────────────────────────────────────────

export async function handlePrivateMessage(context: MessageContext): Promise<void> {
  const { ctx, text, senderName } = context;
  const normalized = text.trim().toLowerCase();

  logger.info(`[PRIVADO] Mensagem recebida`, { sender: senderName, text });

  // Comandos especiais no privado
  if (normalized === '/help' || normalized === 'help') {
    await ctx.sendActivity(
      `👋 Olá, **${senderName}**!\n\n` +
        `📋 **Comandos disponíveis:**\n\n` +
        `• \`/help\` — Exibe esta ajuda\n` +
        `• \`/ping\` — Testa a conexão\n` +
        `• \`/info\` — Informações do bot\n\n` +
        `_Ou envie qualquer mensagem e responderei!_`
    );
    return;
  }

  if (normalized === '/ping') {
    await ctx.sendActivity('🏓 **Pong!** Conexão funcionando perfeitamente.');
    return;
  }

  if (normalized === '/info') {
    const uptime = Math.floor(process.uptime());
    const uptimeStr =
      uptime > 60
        ? `${Math.floor(uptime / 60)}m ${uptime % 60}s`
        : `${uptime}s`;

    await ctx.sendActivity(
      `ℹ️ **Teams Bot — Status**\n\n` +
        `🟢 Online há: **${uptimeStr}**\n` +
        `⚙️ Node.js: ${process.version}\n` +
        `💾 Memória: ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`
    );
    return;
  }

  // Resposta padrão para mensagens livres
  await ctx.sendActivity(
    `💬 Olá, **${senderName}**! Recebi sua mensagem:\n\n` +
      `> ${text}\n\n` +
      `_Use \`/help\` para ver os comandos disponíveis._`
  );
}
